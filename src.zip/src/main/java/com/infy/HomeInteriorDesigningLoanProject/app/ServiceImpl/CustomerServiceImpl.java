package com.infy.HomeInteriorDesigningLoanProject.app.ServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.HomeInteriorDesigningLoanProject.app.IRepository.CustomerRepository;
import com.infy.HomeInteriorDesigningLoanProject.app.IService.CustomerIService;
import com.infy.HomeInteriorDesigningLoanProject.app.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerIService{

	@Autowired
	CustomerRepository cr;
	
	@Override
	public Customer registerCx(Customer cust) 
	{
		Customer c = cr.save(cust);
		return c;
	}

}
