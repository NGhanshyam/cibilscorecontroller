package com.infy.HomeInteriorDesigningLoanProject.app.model;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Data
public class LoanDetails {

	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	private Integer loanDetailId; 
	private Long totalLoanRequired; 
	private Integer tenureofLoan; 
	private Float annualInterest;
	private Long payableLoan;

}
