package com.infy.HomeInteriorDesigningLoanProject.app.model;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Data
public class PropertyDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer propertyId; 
	private String propertyType; 
	private String propertyPrice; 
	private String propertyLocation;
}

