package com.infy.HomeInteriorDesigningLoanProject.app.IService;

import com.infy.HomeInteriorDesigningLoanProject.app.model.Customer;

public interface CustomerIService {

	public Customer registerCx(Customer cust);
}
