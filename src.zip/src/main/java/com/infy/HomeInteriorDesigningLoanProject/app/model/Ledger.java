package com.infy.HomeInteriorDesigningLoanProject.app.model;

import javax.persistence.Id;

import lombok.Data;

@Data
public class Ledger {

	@Id
	private Integer ledgerId;
	private String customerName;
	private String ledgerCreationDate;
	private Double totalLoanAmount;
	private Double payableAmountWithIntrest;
	private Integer tenureInYear;
	private Double monthlyEMI;
	private Double amountPaidTillDate;
	private Double remainingAmount;
	private Integer defaulterCount;
	private String previousEmiStatus;
	private String currentMonthEmiStatus;
	private String loanEndDate;
	private String loanStatus;
}
