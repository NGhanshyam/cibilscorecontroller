package com.infy.HomeInteriorDesigningLoanProject.app.model;

public class ConstumerBankDetails {

}
