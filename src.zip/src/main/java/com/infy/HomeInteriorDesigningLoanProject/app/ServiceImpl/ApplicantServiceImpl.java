package com.infy.HomeInteriorDesigningLoanProject.app.ServiceImpl;

import org.springframework.stereotype.Service;

import com.infy.HomeInteriorDesigningLoanProject.app.IService.ApplicantIService;

@Service
public class ApplicantServiceImpl implements ApplicantIService {

}
