package com.infy.HomeInteriorDesigningLoanProject.app.model;

import javax.persistence.CascadeType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.Data;

@Data
public class LoanApprovedList {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	private Integer loanAid;
	@OneToOne(cascade = CascadeType.ALL)
	private Applicant applicant; 
	@OneToOne(cascade = CascadeType.ALL)
	private LoanDetails loanDetails; 
	@OneToOne(cascade = CascadeType.ALL)
	private Sanction sanction;

}
