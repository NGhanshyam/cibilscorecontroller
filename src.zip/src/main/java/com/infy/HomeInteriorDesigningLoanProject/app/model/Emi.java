package com.infy.HomeInteriorDesigningLoanProject.app.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Emi
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	private Integer emiid;
	private Long loanamt;
	private Integer tenure;
	private Double roi;
	private Long interestamt;
	private Long totalamt;
}
