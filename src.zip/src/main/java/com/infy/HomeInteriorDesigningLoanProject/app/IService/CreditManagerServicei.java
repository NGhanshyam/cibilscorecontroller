package com.infy.HomeInteriorDesigningLoanProject.app.IService;

import java.util.List;

import javax.mail.MessagingException;

import com.infy.HomeInteriorDesigningLoanProject.app.model.EmailSender;
import com.infy.HomeInteriorDesigningLoanProject.app.model.LoanApprovedList;
import com.infy.HomeInteriorDesigningLoanProject.app.model.LoanDetails;
import com.infy.HomeInteriorDesigningLoanProject.app.model.PermanantAddress;
import com.infy.HomeInteriorDesigningLoanProject.app.model.SanctionLetter;

public interface CreditManagerServicei {

	LoanApprovedList savelal(LoanApprovedList lal);

	List<LoanApprovedList> getLoanApprovedList();

	LoanApprovedList getLoanApprovedList(int id);

	SanctionLetter savesanction(int id, LoanApprovedList lallist, SanctionLetter sl);

	List<SanctionLetter> getSanctionLetterData();

	SanctionLetter getDataForLetter(int id);

	void sendEmailWithAttachment(EmailSender es) throws MessagingException; 
	
	PermanantAddress savePAddress(PermanantAddress paddr);

	LoanDetails saveLoanData(LoanDetails loan);

}
