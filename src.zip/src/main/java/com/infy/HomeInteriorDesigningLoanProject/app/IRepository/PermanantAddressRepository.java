package com.infy.HomeInteriorDesigningLoanProject.app.IRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infy.HomeInteriorDesigningLoanProject.app.model.PermanantAddress;

public interface PermanantAddressRepository extends JpaRepository<PermanantAddress, Integer>{

}
