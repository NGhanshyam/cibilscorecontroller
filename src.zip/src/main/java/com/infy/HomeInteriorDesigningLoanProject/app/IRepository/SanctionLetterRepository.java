package com.infy.HomeInteriorDesigningLoanProject.app.IRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infy.HomeInteriorDesigningLoanProject.app.model.SanctionLetter;

public interface SanctionLetterRepository extends JpaRepository<SanctionLetter, Integer>{

	SanctionLetter findBySanctionId(int id);

}
